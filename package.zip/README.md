# Masjid Al-Ikhlas Website dengan Admin Panel

Website modern untuk Masjid Al-Ikhlas yang berada di Rawabadak Utara, Koja, Jakarta Utara. Dibuat menggunakan Next.js, TypeScript, Tailwind CSS, dan Framer Motion dengan sistem admin untuk mengelola kegiatan dan donasi.

## 🕌 Fitur Website

- **Hero Section** - Banner selamat datang dengan animasi yang menawan
- **🌙 Hitung Mundur Ramadan** - Countdown otomatis menuju bulan suci Ramadan
- **Jadwal Waktu Sholat** - Menampilkan 5 waktu sholat harian
- **Tentang Masjid** - Informasi sejarah dan visi masjid
- **Kegiatan & Pengumuman** - Event dinamis dari database admin
- **Donasi Online** - Program donasi dengan progress tracking real-time
- **Kontak & Lokasi** - Informasi lengkap dengan peta Google Maps
- **Responsive Design** - Tampilan optimal di semua perangkat
- **Smooth Animations** - Menggunakan Framer Motion untuk animasi yang halus

## 🔐 Panel Admin

**URL Admin Panel**: `http://localhost:3000/masjid-admin-panel-2025`

- **Dashboard Admin** - Overview statistik kegiatan dan donasi
- **Kelola Kegiatan** - CRUD operations untuk kegiatan masjid (dengan halaman edit)
- **Kelola Donasi & Infaq** - Kelola program donasi dengan progress tracking (dengan halaman edit)
- **Database JSON** - Sistem database sederhana dengan file JSON
- **API RESTful** - Endpoint untuk semua operasi CRUD
- **Security Enhanced** - Admin panel menggunakan route yang lebih aman

## 🚀 Teknologi

- **Next.js 14** - Framework React modern
- **TypeScript** - Typed JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Animation library untuk React
- **Heroicons** - Beautiful hand-crafted SVG icons
- **React Intersection Observer** - Lazy loading dan scroll animations

## 🛠️ Instalasi & Menjalankan

```bash
# Clone repository
git clone [url-repository]
cd masjid-al-ikhlas-website

# Install dependencies
npm install

# Inisialisasi database dengan data contoh
node init-db.js

# Jalankan development server
npm run dev

# Build untuk production
npm run build

# Start production server
npm start
```

### Akses Admin Panel
Setelah server berjalan, akses:
- **Website**: http://localhost:3000
- **Admin Panel**: http://localhost:3000/admin

### Mengelola Content
1. **Kegiatan**: http://localhost:3000/admin/activities
2. **Donasi**: http://localhost:3000/admin/donations

## 📁 Struktur Proyek

```
├── app/
│   ├── layout.tsx          # Layout utama aplikasi
│   ├── page.tsx           # Halaman home
│   ├── globals.css        # Global styles
│   ├── admin/             # Panel admin
│   │   ├── layout.tsx     # Layout admin
│   │   ├── page.tsx       # Dashboard admin
│   │   ├── activities/    # Kelola kegiatan
│   │   └── donations/     # Kelola donasi
│   └── api/               # API endpoints
│       ├── activities/    # CRUD kegiatan
│       └── donations/     # CRUD donasi
├── components/
│   ├── Navigation.tsx     # Komponen navigasi
│   ├── Hero.tsx           # Section hero
│   ├── RamadanCountdown.tsx # Hitung mundur Ramadan
│   ├── PrayerTimes.tsx    # Jadwal waktu salat
│   ├── About.tsx          # Section tentang
│   ├── Events.tsx         # Kegiatan dan event (dengan API)
│   ├── Donation.tsx       # Donasi dan infaq (dengan API)
│   ├── Contact.tsx        # Kontak dan lokasi
│   └── Footer.tsx         # Footer website
├── lib/
│   └── database.ts        # Database operations
├── data/                  # JSON database files
│   ├── activities.json    # Data kegiatan
│   └── donations.json     # Data donasi
├── public/
│   └── images/           # Folder gambar
└── styles/
    └── globals.css        # Custom CSS
```

## 🎨 Desain

Website menggunakan skema warna yang terinspirasi dari seni Islam:
- **Primary**: Teal (#0d9488) untuk identitas utama
- **Accent**: Gold (#e5b53d) untuk aksen dan highlight
- **Neutral**: Gray scale untuk teks dan background
- **Typography**: Cormorant Garamond (heading) + Inter (body)

## 📱 Fitur Responsif

- Mobile-first design approach
- Breakpoints: Mobile (<768px), Tablet (768px-1024px), Desktop (>1024px)
- Touch-friendly navigation untuk mobile
- Optimized images untuk semua device sizes

## 🔧 Kustomisasi

### Mengubah Konten
- Edit file komponen untuk mengubah konten
- Update gambar di folder `public/images/`
- Sesuaikan jadwal salat di `PrayerTimes.tsx`

### Mengubah Styling
- Customize color scheme di `tailwind.config.js`
- Edit global styles di `app/globals.css`
- Adjust component styling di masing-masing file komponen

### Menambah Halaman Baru
- Buat file baru di folder `app/`
- Import dan tambahkan ke navigation di `Navigation.tsx`

## 📈 SEO & Performance

- Next.js App Router untuk optimal performance
- Image optimization dengan Next.js Image component
- Semantic HTML structure
- Meta tags untuk SEO
- Lazy loading untuk images
- Optimized bundle size

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 🔄 Update Terbaru (November 2025)

### Perbaikan yang Dilakukan:
- ✅ **Lokasi Masjid Diperbarui** - Alamat sekarang sesuai: Jl. Janur Kuning No.1, RT.5/RW.10, Rawabadak Utara, Kec. Koja, Jkt Utara, Daerah Khusus Ibukota Jakarta 14230, Indonesia
- ✅ **Keamanan Admin Panel** - Route admin diubah dari `/admin` ke `/masjid-admin-panel-2025` untuk keamanan yang lebih baik
- ✅ **Halaman Edit Ditambahkan** - Sekarang admin bisa edit kegiatan dan donasi yang sudah ada
- ✅ **Animasi Countdown Diperbaiki** - Mengurangi animasi berlebihan pada countdown Ramadan untuk performa yang lebih baik
- ✅ **Icon Jadwal Sholat Diperbaiki** - Icon yang aneh diganti dengan icon yang lebih cocok dan mudah dibaca
- ✅ **Responsive Design Diperbaiki** - Perbaikan layout untuk mobile dan tablet pada halaman admin
- ✅ **UI/UX Improvements** - Perbaikan spacing, typography, dan elemen visual untuk pengalaman pengguna yang lebih baik

## 📝 License

MIT License - lihat file LICENSE untuk detail

## 🤝 Kontribusi

Kontribusi sangat diterima! Silakan:
1. Fork repository
2. Buat feature branch
3. Commit changes
4. Push to branch
5. Buat Pull Request

## 📞 Kontak

Untuk pertanyaan atau bantuan, hubungi:
- Email: info@masjidalikhlas.org
- Telepon: (021) 4567-8901
- Alamat: Jl. Janur Kuning No.1, RT.5/RW.10, Rawabadak Utara, Kec. Koja, Jkt Utara, Daerah Khusus Ibukota Jakarta 14230, Indonesia

---

Dibuat dengan ❤️ untuk ummat Muslim di Rawabadak Utara, Koja, Jakarta Utara